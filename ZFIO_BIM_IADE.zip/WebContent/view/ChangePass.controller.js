sap.ui.controller("cus.PKT.BIMIADE.view.ChangePass", {
    onInit: function() {
    	 this.oView = this.getView();
         this.oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.oView));
         this.oResourceBundle = this.oComponent.getModel(this.oComponent.i18nModelName).getResourceBundle();
         this.oRouter = this.oComponent.getRouter();
         this.oRouter.attachRoutePatternMatched(this.onRoutePatternMatched, this);
    }

,
		onRoutePatternMatched: function(oEvent){
			this.uname =oEvent.mParameters.arguments.Username;
			this.byId("idUserNameInput").setValue(this.uname);
			
		},
		 onNavBack: function() {
		        cus.PKT.BIMIADE.util.Util.onNavBack(-1, true);
		    },
		handleChangePassword: function (oEvent){
			
			var username 	= this.byId("idUserNameInput").getValue();
			var oldpass 	= this.byId("idOldPass").getValue();
			var newpass 	= this.byId("idNewPass").getValue();
			var newpassre	= this.byId("idNewPassRe").getValue();
			
			
			if( username == "" || oldpass== ""|| newpass=="" || newpassre==""){
				
				sap.m.MessageBox.alert("Bütün Alanları Doldurunuz");
				
			}else{
				if(newpass!=newpassre){
					sap.m.MessageBox.alert("Şifreler Eşleşmiyor");
					
				}else{
					
					if( newpass == oldpass){
						sap.m.MessageBox.alert("Eski Şifre ve Yeni Şifre aynı olamaz");
						return;
					}
					
					 this.oView.getModel().callFunction("/ChangePassword", {
				            urlParameters: {
				            	NewPassword: newpass,
				            	Password: oldpass,
				            	Username: username 
				            },
				            success: function(oData, Response) {
				            	if(oData.Return =="S"){
				            		
				            		sap.m.MessageBox.alert( oData.Message ,{
				            			onClose: function(oAction) { 		            					
				            				  cus.PKT.BIMIADE.util.Util.onNavBack(-1, true);
				            			
				            			
				            			}}
				            		);
				            		}
				            		
				            	else{
				            		
				            		sap.m.MessageBox.alert(oData.Message);
				            	}
				            	
				            },
				            error: function(error) {
				            	debugger;
				            },
				        }); 
					
					
					
					
					
				}
					
			}
	
		}

});