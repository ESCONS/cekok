sap.ui.controller("cus.PKT.BIMIADE.view.MyBills", {
    onInit: function() {
        this.oView = this.getView();
        this.oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.oView));
        this.oResourceBundle = this.oComponent.getModel(this.oComponent.i18nModelName).getResourceBundle();
        this.oRouter = this.oComponent.getRouter(); 
        this.sSubcriptionModelName = "SubcriptionModel";
        this.sOpenItemModelName = "OpenItemModel";
        this.sBankModelName = "BankModel";
        this.sInstModelName = "InstModel"
        this.OkUrl = "http://tekasaptest.tekahq.local:8000/sap/bc/bsp/sap/yesc_fsp_fail/ok.htm";
        this.FailUrl = "http://tekasaptest.tekahq.local:8000/sap/bc/bsp/sap/yesc_fsp_fail/fail.htm";
        this.CompanyFragmentId = this.getView().createId("idCompanyInfo"); 
        this.TekaFragmentId = this.getView().createId("idTekaInfo");  
        this.links;
        this.oControls = {
        	sVposCardName: this.byId("idCardName"),
            sVPosBankSelect: this.byId("vPosBankSelect"),
            sVPosInstallmentSelect: this.byId("vPosInstallmentSelect"),
            svPosSelectedInput: this.byId("vPosSelectedInput"),
            vPosPayInput: this.byId("vPosPayInput"),
            vPosRemaningInput: this.byId("vPosRemaningInput"),
            vPosCardNumber: this.byId("idCardNumber"),
            vPosMonth: this.byId("idMonth"),
            vPosYear: this.byId("idYear"),
            vPosCvc : this.byId("idCvcNo") 
        };
        this.bindDataIsBank = [];
        this.oRouter.attachRoutePatternMatched(this.onRoutePatternMatched, this);
        if(sap.ui.core.routing.History.getInstance(1).aHistory["0"].includes("okUrl"))
        	location.reload();
    },

    onRoutePatternMatched: function(oEvent) {
    	var t = this;  
    	this.userID = oEvent.mParameters.arguments.userID;
        this.sPageName = oEvent.getParameter("name");
        var user = cus.PKT.BIMIADE.util.Util.parseCookie("user"); 
        if (this.sPageName === "mybills") { 
            this.UserInfo = {};
            this.oModel = this.oView.getModel();
            this._refreshPageControl(); 
            this._dateModel();
            this.tuketiciText = ""; 
//             this.byId("idContentUserName").setText(user.Uname);
            this._setBankModelselects();
            // this._setInstModelselects();
            if (user !== "") {
                this.UserInfo = user;
                if (!this.UserInfo.Guid || !this.UserInfo.Kunnr || !this.UserInfo.Bukrs) {
                    this._navToLogin();
                } else {
                    this.byId("IdUsername").setText(this.UserInfo.Uname);
//                    this._getExTable();  
                    this.bindCompanyInfo("1000", "").then(function(oData) {        
        				return t.InfoBind(oData, t.TekaFragmentId); 
        			})
        			t.bindCompanyInfo("", t.UserInfo.Kunnr ).then(function(oData) {        
        				return t.InfoBind(oData, ""); 
        			})
        			t.readNotif().then(function(data){
        				
        				for(var i = 0; i < data.length; i++){
        					var textLine = "";
        					if(data[i].Tdformat === "*" && data[i].Tdline === ""){ //alt satıra geç
        						 textLine = "\n"; 
        						t.tuketiciText = t.tuketiciText + textLine;
        					}
        					if(data[i].Tdformat === "*" && data[i].Tdline.search(":") !== -1){  
        						textLine =  "\n" + data[i].Tdline + "\n" + "\n";
        						t.tuketiciText = t.tuketiciText + textLine;
        					}else{
        						textLine = data[i].Tdline;
        						t.tuketiciText = t.tuketiciText + textLine;
        					} 
        				}
        				t.byId("idMessageStrip").setText(t.tuketiciText)
        			})
                	.catch(function(error) {  
                    sap.m.MessageBox.alert(t.oResourceBundle.getText("ERROR"));
                    });
                    this._getExTable(); 
                }
            }
        } 
//        this.imageClick(); 
        var abc = "123";
        window.numberFour = "****";
        this.byId("idCardNumber").attachBrowserEvent('keypress', function(e){
        if(e.target.selectionStart < 15){
        		return;
        	}else if(e.target.selectionStart > 18){
        		return;
        	}else{
        		if(e.target.selectionStart === 15 && e.originalEvent.key.match(/[a-zA-Z]/) === null ){
        			window.number0 = e.originalEvent.key;  
        			_timeout = jQuery.sap.delayedCall(0200, this, function () {
        				this.byId("idCardNumber").setValue(e.target.value.substr(0,15) + "*");
        				return false;
        			}); 
        			return true;
        		}else if(e.target.selectionStart === 16 && e.originalEvent.key.match(/[a-zA-Z]/) === null){
        			window.number1 = e.originalEvent.key;
        			_timeout = jQuery.sap.delayedCall(0200, this, function () {
        				this.byId("idCardNumber").setValue(e.target.value.substr(0,16) + "*");
        				return false;
        			}); 
        			return true;
        		}else if(e.target.selectionStart === 17 && e.originalEvent.key.match(/[a-zA-Z]/) === null){
        			window.number2 = e.originalEvent.key;
        			_timeout = jQuery.sap.delayedCall(0200, this, function () {
        				this.byId("idCardNumber").setValue(e.target.value.substr(0,17) + "*");
        				return false;
        			}); 
        			return true;
        		}else if(e.target.selectionStart === 18 && e.originalEvent.key.match(/[a-zA-Z]/) === null){
        			window.number3 = e.originalEvent.key;
        			_timeout = jQuery.sap.delayedCall(0200, this, function () {
        				this.byId("idCardNumber").setValue(e.target.value.substr(0,18) + "*");
        				this._getCardType(e.target.value.substr(0,18) + "*")
        				return false;
        			}); 
        			return true;
        		}
        	}
            // check key code
          debugger;
       }, this);
        
        
    },
    
    changedNumberCardNo: function(a, b){
    	var t = this;
    	this.byId("idCardNumber").setValue(a + "*")
    },
    
    readNotif: function(){
        var t = this; 
        return new Promise(function(resolve, reject) {	 
            t.oView.getModel().callFunction("/TuketiciFunction", {  
                success: function(oData, oResponse) { 
	                resolve(oData.results);  
                },
                error: function(err) { 
                	sap.m.MessageBox.alert(t.oResourceBundle.getText("NOTIF_NOT_FOUND"));
                	reject();
                }
            });  
        });  
    	
    },
    
    imageClick: function(){
    	var t = this;
    	this.oldController = [];
    	this.byId("idImageMaster").attachPress( function(oControlEvent){ 
    		var items = oControlEvent.oSource.oParent.mAggregations.items; 
      		var oId = oControlEvent.oSource.sId;
    		for(var i = 0; i < items.length; i++){
    			if(items[i].sId !== oId){
    				items[i].removeStyleClass("SelectImage");
    			}
    		}
        	oControlEvent.oSource.addStyleClass("SelectImage"); 
        	window.selectedCardType = "Master";
            });
      	this.byId("idImageVisa").attachPress( function(oControlEvent){  
      		var items = oControlEvent.oSource.oParent.mAggregations.items; 
      		var oId = oControlEvent.oSource.sId;
    		for(var i = 0; i < items.length; i++){
    			if(items[i].sId !== oId){
    				items[i].removeStyleClass("SelectImage");
    			}
    		}  
        	oControlEvent.oSource.addStyleClass("SelectImage");  
        	window.selectedCardType = "Visa";
            }); 
      	this.byId("idImageAmerican").attachPress( function(oControlEvent){  
      		var items = oControlEvent.oSource.oParent.mAggregations.items; 
      		var oId = oControlEvent.oSource.sId;
    		for(var i = 0; i < items.length; i++){
    			if(items[i].sId !== oId){
    				items[i].removeStyleClass("SelectImage");
    			}
    		}  
        	oControlEvent.oSource.addStyleClass("SelectImage");  
        	window.selectedCardType = "AmericanExpress";
            }); 
    },
    
    _getCryptCardNo: function(oEvent) {
    	var t = this;
    	debugger;
    	var v = e.getParameter('liveValue').trim();
    	this.byId("idCardNumber").getValue();
    },
    
    _getCardType: function (oEvent){
    	if(oEvent.getParameter !== undefined ){ 
        	var number = oEvent.getParameter("value").replace(/-/g, '');
    	}else{
    		var number = oEvent.replace(/-/g, '');
    	}
    	var items = ["idImageMaster","idImageVisa","idImageAmerican"]
    	for(var i = 0; i < items.length; i++){ 
		    this.byId(items[i]).removeStyleClass("SelectImage"); 
		} 
    	
    	
        // visa
        var re = new RegExp("^4");
        if (number.match(re) != null){
        	this.byId("idImageVisa").addStyleClass("SelectImage");  
    	    window.selectedCardType = "Visa";
            return "Visa";
        }
        	

        // Mastercard 
        // Updated for Mastercard 2017 BINs expansion
        re = new RegExp("^5[1-5]");
        if (number.match(re) != null){

       	 this.byId("idImageMaster").addStyleClass("SelectImage"); 
     		window.selectedCardType = "Master";  
            return "Mastercard";
        	
        }
            
        // AMEX
        re = new RegExp("^3[47]");
        if (number.match(re) != null){
        	this.byId("idImageAmerican").addStyleClass("SelectImage");   
    	    window.selectedCardType = "AmericanExpress";
            return "AMEX";
        }
        	

        // Discover
        re = new RegExp("^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)");
        if (number.match(re) != null){
        	 return "Discover";
        }
           

//        // Diners
//        re = new RegExp("^36");
//        if (number.match(re) != null)
//            return "Diners";
//
//        // Diners - Carte Blanche
//        re = new RegExp("^30[0-5]");
//        if (number.match(re) != null)
//            return "Diners - Carte Blanche";
//
//        // JCB
//        re = new RegExp("^35(2[89]|[3-8][0-9])");
//        if (number.match(re) != null)
//            return "JCB";
//
//        // Visa Electron
//        re = new RegExp("^(4026|417500|4508|4844|491(3|7))");
//        if (number.match(re) != null)
//            return "Visa Electron";

        return "";
    },
    
    InfoBind: function(values, fragment){
    	var t = this; 
    	if(fragment == this.TekaFragmentId){
    		var oCompany = sap.ui.core.Fragment.byId(fragment, "idCompanyName");
        	oCompany.setText(values.Name1);
        	var oAdress = sap.ui.core.Fragment.byId(fragment, "idAddress");
        	oAdress.setText(values.City2 + "  /  " + values.City1 + "  /  " + values.Street  + "  /  " + values.PostCode1); 
        	var oPhoneNo = sap.ui.core.Fragment.byId(fragment, "idPhoneNo");
        	oPhoneNo.setText(values.TelNumber);
        	var oFaxNo = sap.ui.core.Fragment.byId(fragment, "idFaxNo");
        	oFaxNo.setText(values.FaxNumber);
    	}else{
    		var oCompany = sap.ui.core.Fragment.byId(this.TekaFragmentId, "idCompCompanyName");
        	oCompany.setText(values.Name1);
        	var oAdress = sap.ui.core.Fragment.byId(this.TekaFragmentId, "idCompAddress");
        	oAdress.setText(values.City2 + "  /  " + values.City1 + "  /  " + values.Street  + "  /  " + values.PostCode1); 
        	var oPhoneNo = sap.ui.core.Fragment.byId(this.TekaFragmentId, "idCompPhoneNo");
        	oPhoneNo.setText(values.TelNumber);
        	var oFaxNo = sap.ui.core.Fragment.byId(this.TekaFragmentId, "idCompFaxNo");
        	oFaxNo.setText(values.FaxNumber);
    	}
    	
    	
    },
    
    	safeExit: function(){
    	
    	
    		this.oRouter.navTo("login", {
        		

            });
    	
    },
    
    
    bindCompanyInfo: function(sBukrs, sKunnr) {
        var t = this; 
        return new Promise(function(resolve, reject) {	 
            t.oView.getModel().read("/CompanyInfoSet(Bukrs='"+ sBukrs + "',Kunnr='"+ sKunnr + "')" , {  
                success: function(oData, oResponse) { 
	                resolve(oData);  
                },
                error: function(err) { 
                	sap.m.MessageBox.alert(t.oResourceBundle.getText("COMPANY_NOT_FOUND"));
                	reject();
                }
            });  
        });     
    },
    
    messagePopop : function(){
    	if(!this.checked){
    		this.checked = true; 
            this.MessagePopover.open();
    	} 
    	this.MessagePopover.close(); 
    },

    onNavBack: function() {
        cus.PKT.BIMIADE.util.Util.onNavBack(-1, true);
    },

    _navToLogin: function() {
        this.oRouter.navTo("login", {});
    }, 
    _getExTable: function() {
        var t = this; 
        this.oView.getModel().callFunction("/FinCustStatment", {
            urlParameters: {
                CompCode: t.UserInfo.Bukrs,
                Customer: t.UserInfo.Kunnr
            },
            success: function(oData, Response) {
            	var a = oData.results;
            	
            	
                var oInvoiceModel = new sap.ui.model.json.JSONModel({
                    OpenItemCollection:  a
                });
                t.oView.setModel(oInvoiceModel, t.sOpenItemModelName);
                t.bindDataIsBank = oData.results; 
            },
            error: function(error) {
                var resp = JSON.parse(error.response.body);
                var sErrorText = resp.error.message.value;
                sap.m.MessageBox.alert(t.oResourceBundle.getText("INVOICE_NOT_FOUND", sErrorText)); 
            },
        }); 
    },
    
    _dateModel: function(){
    	var t = this;
    	var dataMonth = []; var dataYear = [];
    	
    	 var oMonth = new sap.ui.model.json.JSONModel({ localMonthCollection: [] });
    	 
    	 var oYear = new sap.ui.model.json.JSONModel({ localYearCollection: [] });
 
    	 for (var i = 1; i <= 12; i++) {
    		 var month = ({  Month: i,  })
    		 dataMonth.push(month);
    		}
    	 dataMonth.unshift({ Month: ""})
    	 var sYear = new Date().getFullYear()
    	 for (var i = 0; i <= 20; i++) {  
    		var year = ({  Year: sYear + i, })
    		dataYear.push(year);
  		}

    	 dataYear.unshift({ Year: ""})
    	 oMonth.setProperty("/localMonthCollection", dataMonth); 
         oYear.setProperty("/localYearCollection", dataYear);
         
         this.oView.setModel(oMonth, "localMonthModel");
         this.oView.setModel(oYear, "localYearModel");
    },
    
    onPaymentDif: function(){ 
    	var t = this;
    	var sFark = this.oPrice - cus.PKT.BIMIADE.util.formatter.amountFormatterConna(this.oControls.vPosPayInput.getValue());
    	if(sFark === 0){
    		this.byId("idRemaningForm").setVisible(false);
    	}else{
    		this.byId("idRemaningForm").setVisible(true);
    		if(sFark.toString().search("-") === 0){
    			sFark = sFark.toString().replace("-", "")
        		this.byId("idRemaningInput").setText(this.oResourceBundle.getText("REMAINING_AMOUNT_2"));
        	}else{ 
        		this.byId("idRemaningInput").setText(this.oResourceBundle.getText("REMAINING_AMOUNT"));
        	}
    	}
    	
    	this.oControls.vPosRemaningInput.setValue(cus.PKT.BIMIADE.util.formatter.amountFormatterWithoutCurrency(sFark));
    },
    
    _setBankModelselects: function() {
        var t = this;
        this.byId("vPosInstallmentSelect").setEnabled(false);
        var Bank1 = this.sInstallmentCount === undefined ? this.oControls.sVPosBankSelect.getSelectedKey() : this.sInstallmentCount;

        this.oView.getModel().callFunction("/FinBanka", {
            urlParameters: {
            	Bank1: Bank1 === "00" ? "" : Bank1
            },
            success: function(oData, Response) {
            	   oData.results.unshift({
            		   Bankl: "",
            		   Banka: "Lütfen Banka Seçiniz"
                 }); 

                var oBankModel = new sap.ui.model.json.JSONModel({
                    BankCollection: oData.results
                });
                t.oView.setModel(oBankModel, t.sBankModelName);
                 
            },
            error: function(error) {
                sap.m.MessageBox.alert(t.oResourceBundle.getText("PAGE_URL_DATA_GET_ERROR"));
            },
        });
    },
    
    clearPage: function(){
    	var t = this;
    	var sInput = ["idCardName","idCardNumber","idCvcNo","vPosPayInput", "vPosSelectedInput", "vPosRemaningInput","idVadeFarkInput"];
    	var sSelect = ["vPosBankSelect","idMonth","idYear","vPosInstallmentSelect"]; 
    	for(var i = 0; i < sInput.length; i++){
    		if(this.byId(sInput[i]).getValue() !== ""){
    			this.byId(sInput[i]).setValue("");  
    		} 
    	}
    	
    	for(var i = 0; i < sSelect.length; i++){
    		if(this.byId(sSelect[i]).getSelectedKey() !== ""){
    			this.byId(sSelect[i]).setSelectedKey("");  
    		} 
    	}
    	this.byId("idVadeFarkForm").setVisible(false);
    	this.byId("idRemaningForm").setVisible(false);
    	this.byId("idBillTable").clearSelection();
    	
    },

    _setInstModelselects: function() {
        var t = this; 
        if(this.oControls.sVPosBankSelect.getSelectedKey() == "" || this.oControls.sVPosBankSelect.setSelectedKey == "null"){
        	
        	  sap.m.MessageBox.show(
      				"Önceden girdiğiniz değerler silinsin mi ?", {
      					icon:   sap.m.MessageBox.Icon.QUESTION,
      					title: "Uyarı",
      					actions: [  sap.m.MessageBox.Action.YES,   sap.m.MessageBox.Action.NO],
      					onClose: function(sAnswer) {
      						if (sAnswer === sap.m.MessageBox.Action.YES) { 
      							t.clearPage();
      						}else{
      							sap.m.MessageBox.alert("Banka seçimi yaparak devam ediniz");
      							return;
      						}
      					}
      				}
      			); 
        }
        this.oView.getModel().callFunction("/FinInstallment", {
            urlParameters: {
                 Bankl: this.oControls.sVPosBankSelect.getSelectedKey()
            },
            success: function(oData, Response) {
                 oData.results.unshift({
                	 Bankl          : "",
                	 YescTaksit     : "Lütfen ödeme biçimini seçiniz",
                	 YescFaizoran   : "",
                	 YescGunsayi    : "",

                 });
                var oInstModel = new sap.ui.model.json.JSONModel({
                    InstallmentCollection: oData.results
                });
                t.oView.setModel(oInstModel, t.sInstModelName);
                t.byId("vPosInstallmentSelect").setEnabled(true);
            },
            error: function(error) {
                sap.m.MessageBox.alert(t.oResourceBundle.getText("PAGE_URL_DATA_GET_ERROR"));
            },
        });
        
        var bank = t.byId("vPosBankSelect").getSelectedKey();
		var input ;
		switch (bank.substr(0,4)) {
		case "0064": 
			input = "ISBANK";
		case "0067": 
			input = "YAPIKREDI";
		case "0062":
			input = "GARANTI";
		case "0046" : 
			input = "AKBANK";
		case "0012": 
			input = "HALKBANK"; 
		default:
			break;
		}
		
        t.oView.getModel().callFunction("/GetBankLinks", {
              urlParameters: {
              	Bank: input
              },
              success: function(oData, Response) {
           
              	t.links = oData ; 
              	
              	},
              error: function(error) {
           
              		
              },
          });
    },
    
    setButtonVisiblity(boolean){
    	
    	var t = this;
    	
    	if(!boolean){
    		t.byId("idFaturaPay").setVisible(true);
    		t.byId("idAvansPay").setVisible(false);
    	}else{
    		t.byId("idFaturaPay").setVisible(false);
    		t.byId("idAvansPay").setVisible(true);  		
    	}
	
    },
    
    _setVadeFark: function(oEvent){
    	var t = this; 
    	
    	if(this.oControls.sVPosInstallmentSelect.getSelectedKey() == ""){ 
    		sap.m.MessageBox.alert("Ödeme biçimi seçiniz");
    		return;
    	}
    	if(this.byId("idBillTable").getSelectedIndices().length == 0){
    		return;
    	}
    	if(this.oControls.sVPosInstallmentSelect.mBindingInfos.items.binding === undefined){
    		return;
    	}
    	var selectedBındItem = this.oControls.sVPosInstallmentSelect.mBindingInfos.items.binding.oList[this.oControls.sVPosInstallmentSelect.getSelectedIndex()]
    	
    /*	if(selectedBındItem.YescTaksit == "0"){
        	this.byId("idVadeFarkForm").setVisible(false); 
        	this.byId("idVadeFarkInput").setValue("");
    	}*/
    	
    /*	if(selectedBındItem.Bankl !== "" && selectedBındItem.YescTaksit != "0" && parseFloat(this.oControls.vPosPayInput.getValue().replace(/[",","."]/g, '')) !== 0){
            this.oView.getModel().callFunction("/VadeFarkFunction", {
                urlParameters: {
                     Bankl  : selectedBındItem.Bankl,
                     Taksit : selectedBındItem.YescTaksit,
                     Total  : parseFloat(this.oControls.vPosPayInput.getValue().replace(/[",","."]/g, ''))
                },
                success: function(oData, Response) {
                	t.byId("idVadeFarkForm").setVisible(true);
                	t.byId("idVadeFarkInput").setValue(oData.results[0].Vade);
                },
                error: function(error) {
                	t.byId("idVadeFarkForm").setVisible(false); 
                	t.byId("idVadeFarkInput").setValue("");
                    sap.m.MessageBox.alert("Faiz hesaplamasında bir hata oluştu.");
                },
            });
    	}*/
    	
    },

    /* _setBankModelselects: function() {
         var t = this;
         var sPath = "/BankSet";
         this.oModel.read(sPath, null, null, true, function(oBankResult) {
             var oBanks = oBankResult.results;
             oBanks.unshift({
                 BankCode: t.oDefaultValue.key,
                 BankTxt: t.oDefaultValue.value
             });
             var oBankModel = new sap.ui.model.json.JSONModel({
                 BankCollection: oBanks
             });
             t.oView.setModel(oBankModel, t.sBankModelName);
         }, function(error) {
             sap.m.MessageBox.alert("BankSet Read Fail : " + error.message);
         });
     },*/

    onRowSelectionChange: function(oEvent) {
    	var t = this;
        var oTable = this.byId("idBillTable");
        var selectedIndex = oTable.getSelectedIndices();
        if(selectedIndex.length == 0){
        	this.setButtonVisiblity(true);
        }else {
        	this.setButtonVisiblity(false);
        }
        
        var price = 0;
        for (var i = 0; i < selectedIndex.length; i++) {
            var oContext = oTable.getContextByIndex(selectedIndex[i]);
            if(parseFloat(oContext.getProperty("KalanTutar")) === 0){
                sap.m.MessageBox.alert("Fatura No : " + oContext.getProperty("DocNo")      + "\n" +
                		               " Referans No: " + oContext.getProperty("RefDocNo") + "\n" + "\n" +
                		               " Kalan tutar sıfır olduğu için ödeme yapılamaz. BLABLA uyarlama tablosundan kontrol ediniz.")
            	oTable.clearSelection()
            	return;
            }
            price += parseFloat(oContext.getProperty("KalanTutar"));
        }
        this.oPrice = price;
        if(i > 0){ 	
            this.oControls.svPosSelectedInput.setValue(i + " Fatura seçildi, Tutar :  " + cus.PKT.BIMIADE.util.formatter.amountFormatterWithoutCurrency(price));
        }else{ 
            this.oControls.svPosSelectedInput.setValue(cus.PKT.BIMIADE.util.formatter.amountFormatterWithoutCurrency(price));
        }
        this.oControls.vPosPayInput.setValue(cus.PKT.BIMIADE.util.formatter.amountFormatterWithoutCurrency(price));
       // this._setVadeFark();
    },

    _refreshPageControl: function() {
        this.oDefaultValue = cus.PKT.BIMIADE.util.Util.getDefaultSelectValue("DEFAULT_VALUE", "PLEASE_SELECT");
        this.oControls.sVPosBankSelect.setSelectedKey(this.oDefaultValue.key);
        this.oControls.sVPosInstallmentSelect.setSelectedKey(this.oDefaultValue.key);
    },

    _checkSelectBox: function() {
        var t = this,
            sBank = null,
            sInstallment = null,
            sPrice = null,
            status = true;
        // if (this.oControls.sVPosBankSelect.getSelectedKey() === this.oDefaultValue.key) {
        //     sBank = this.oResourceBundle.getText("BANK");
        //     status = false;
        // }
        // if (this.oControls.sVPosInstallmentSelect.getSelectedKey() === this.oDefaultValue.key) {
        //     sInstallment = this.oResourceBundle.getText("INSTALLMENT");
        //     status = false;
        // }
        // if (parseFloat(this.oControls.svPosSelectedInput.getValue()) <= 0 || this.oControls.svPosSelectedInput.getValue() === "") {
        //     sPrice = this.oResourceBundle.getText("PRICE");
        //     status = false;
        // }

        if (!status) {
            sap.m.MessageBox.alert(t.oResourceBundle.getText("SELECT_MSG", [sBank === null ? " " : t.oResourceBundle.getText("BANK"),
                sBank === null && sInstallment === null ? " " : t.oResourceBundle.getText("AND"),
                sInstallment === null ? " " : t.oResourceBundle.getText("INSTALLMENT"),
                sPrice === null ? " " : this.oResourceBundle.getText("PRICE")
            ]), {
                icon: sap.m.MessageBox.Icon.WARNING,
                title: t.oResourceBundle.getText("INVOICE_INFORMATIN")
            });
        }

        return status;
    },

//    handlePaySelectedButton: function() { // Yapı değiştirildiği için kaldırıldı.
//        this._payInvoice(this._getPaymentInfo());
//    },
    
  
    
    handlePaySelectedButton: function() { 
    	var t = this;
    	var selection= false;
    	
    	
    	
    	var ID = this.userID;
		  var isbank = ["418342" , "418343" , "418344" , "418345" , "450803" , "454318" , "454358" , "454359" , "454360" , "510152" , "540667" , "540668" , "543771" , "552096" , "553058" ] ;
		
		  var cardno= t.byId("idCardNumber").getValue();
		  var check =  cardno[0] + cardno[1] + cardno[2] + cardno[3] + cardno[5] + cardno[6] ;
    	selection = t.byId("paySelector").getSelected();
    
    	
    	if (selection == true) {
    			
    
    		     var user = this.userID;     
    		     var sKey = this.sInstallmentCount === undefined ? this.oControls.sVPosBankSelect.getSelectedKey() : this.sInstallmentCount;
    		    var saveSet = this._bankTypeData(sKey);
    		    var toEntityType = this._entityTypeData(sKey);
    		    var taksit;
    		    var rnd = "asdf";     
    		    if (saveSet.Instalment=="T"){
    		      taksit= "";
    		    }else{
    		      taksit =  saveSet.Instalment ;
    		      if (!isbank.includes(check)){

    		    sap.m.MessageBox.alert( "Sadece İş Bankası Kartlarına Taksit Yapılabilir") ;
    		    return ;
    		  
    		  }
    		    }
    		    saveSet.GroupId = user;
    		    var json = JSON.stringify(saveSet);
    		  //  var sender = b64EncodeUnicode(json);
    		    var sender = json ;
    		    debugger;
    		    var data = sender.replace("/",".");
    		   
    		
    		    
    		      var okUrl  = t.links.Tekalink + "#/okUrl/success/" + data;
    		      var failUrl = t.links.Tekalink +"#/failUrl";
    		      var postdata= {};
    		      postdata.clientid=t.links.Clientid;
    		      postdata.oid="";
    		      postdata.amount=saveSet.Total.toString();
    		      if(postdata.amount.includes(".")||postdata.amount.includes(".")){
    		        postdata.amount.replace(",",".");

    		      }
    		      else
    		        {
    		        postdata.amount = postdata.amount + ".00";

    		        }

    		      postdata.okUrl=okUrl;
    		      postdata.failUrl=failUrl;
    		      postdata.islemtipi="Auth";
    		      postdata.taksit=taksit;
    		      postdata.rnd="asdf";
    		      postdata.isyerianahtari= t.links.Storekey;
    		      var hashed = cus.PKT.BIMIADE.util.Util.gethash3(postdata);
    		
    		       var postFormStr = "<form method='post' action='"+ t.links.Banklink  +"'>\n"+
    		         "<input type='hidden' name='clientid' value='"+ postdata.clientid +"'/>\n"+
    		         "<input type='hidden' name='oid' value='' />\n"+
    		         "<input type='hidden' name='amount'  value='"+ postdata.amount+"' />\n"+
    		         "<input type='hidden' name='BOLUM' value='4' />\n"+
    		         "<input type='hidden' name='okUrl'value='" +okUrl+ "'/>\n"+
    		         "<input  type='hidden' name='failUrl' value='"+failUrl+ "'/>\n"+
    		         "<input type='hidden' name='islemtipi' value='Auth' />\n"+
    		         "<input type='hidden' name='taksit' value='"+postdata.taksit+"'/>\n"+
    		         "<input type='hidden' name='rnd' value='"  + rnd + "' />\n"+
    		         "<input type='hidden' name='hash' value='" +hashed +"'/>\n" +
    		         "<input type='hidden' name='lang' value='tr' />\n"+
    		         "<input type='hidden' name='storetype' value='3d_pay' />\n"+
    		         "<input type='hidden' name='storekey' value='"+postdata.isyerianahtari+"' />\n"+
    		         "<input type='hidden' name='refreshtime' value='10' />\n"+
    		         "<input type='hidden' name='currency' value='949'>"+
    		         "<input type='hidden' name='lang' value='tr'>"+
    		         "<input type='hidden' name='pan' value='" + saveSet.Number +"' />\n"+
    		         "<input type='hidden' name='cv2' value='"+saveSet.Cvv2Val+"' />\n"+
    		         "<input type='hidden' name='Ecom_Payment_Card_ExpDate_Year' value='"+saveSet.Expires[5]+saveSet.Expires[6]+"' />\n"+
    		         "<input type='hidden' name='Ecom_Payment_Card_ExpDate_Month' value='"+saveSet.Expires[0]+saveSet.Expires[1]+"' />\n"+
    		         "</form>" ;
    		      
    		      
    		       var formElement = $(postFormStr);
    		       $('body').append(formElement);
    		         $(formElement).submit();
    		         var mert =$(formElement).responseText;
    		         var mert = 4 ;
         
    	}else{
    		
    		var oModel = this.oView.getModel();
        	var sKey = this.sInstallmentCount === undefined ? this.oControls.sVPosBankSelect.getSelectedKey() : this.sInstallmentCount;
        	var checked = this.checkedInput();
        	if(checked === "E"){
        		return;
        	}
           
    		var saveSet = this._bankTypeData(sKey);
    		var toEntityType = this._entityTypeData(sKey);
    		
    		  if (saveSet.Instalment=="T"){
    		      taksit= "";
    		    }else{
    		      taksit =  saveSet.Instalment ;
    		      if (!isbank.includes(check)){

    		    sap.m.MessageBox.alert( "Sadece İş Bankası Kartlarına Taksit Yapılabilir") ;
    		    return ;
    		  
    		  }
    		    }
    		  sap.ui.core.BusyIndicator.show(0);
    
            this.oView.getModel().callFunction(toEntityType, {
                urlParameters: saveSet,
                success: function(oData, Response) {
                	if(oData.results[0].Message !== ""){
                		
                		var message= "";
                		for (i=0;i<oData.results.length;i++){
                			message+=	oData.results[i].Message + "\n" ;	
                		}
                		sap.ui.define(["sap/m/MessageBox"], function(MessageBox) {
                 			MessageBox.show(
                 					oData.results[0].Message, {
                 					icon: MessageBox.Icon.INFORMATION,
                 					title: "Bilgilendirme",
                 					actions: [MessageBox.Action.YES],
                 					onClose: function(oAction) { 
                 						location.reload();       					
                 				    	
                 			}
                 				}
                 			);
                 		});
                				
                	}else{
         	}
                	  t.byId("idRemaningForm").setVisible(false);
                	 t._getExTable();
                	 sap.ui.core.BusyIndicator.hide(0);
                },
                error: function(error) {
                	
               sap.m.MessageBox.success("Sisteme Bağlanılamadı");
               	 sap.ui.core.BusyIndicator.hide(0);
                	//FIXME HATA MESAJI
                },
            });
    	}

    },
    
    checkedInput: function(){
    	var t = this;
    	var sInput = ["idCardName","idCardNumber","idCvcNo","vPosPayInput"];
    	var sSelect = ["vPosBankSelect","idMonth","idYear","vPosInstallmentSelect"]; 
    	
    	if(isNaN(parseFloat(window.number0)) !== false &&
    	   isNaN(parseFloat(window.number1)) !== false &&
    	   isNaN(parseFloat(window.number2)) !== false &&
    	   isNaN(parseFloat(window.number3)) !== false){ 
    		this.byId("idCardNumber").setValueState(sap.ui.core.ValueState.Error); 
    		sap.m.MessageBox.alert(t.oResourceBundle.getText("CARD_NO_ERROR"));
			return "E";
		}else{
			this.byId("idCardNumber").setValueState(sap.ui.core.ValueState.None); 
		}
    	
    	for(var i = 0; i < sInput.length; i++){
    		if(this.byId(sInput[i]).getValue() === ""){
    			this.byId(sInput[i]).setValueState(sap.ui.core.ValueState.Error); 
    			return "E";
    		}else{
    			this.byId(sInput[i]).setValueState(sap.ui.core.ValueState.None); 
    		}
    	}
    	
    	for(var i = 0; i < sSelect.length; i++){
    		if(this.byId(sSelect[i]).getSelectedKey() === ""){
    			this.byId(sSelect[i]).setValueState(sap.ui.core.ValueState.Error); 
    			return "E";
    		}else{
    			this.byId(sSelect[i]).setValueState(sap.ui.core.ValueState.None); 
    		}
    	}
    	
    	if(window.selectedCardType === undefined){
    		sap.m.MessageBox.alert(t.oResourceBundle.getText("SELECT_CARD_TYPE_ERROR"));
			return "E";
    	}
    	
    	return "S";
    	
    },
    
    _checkCardDate: function(){
    	
    	var t = this;
    	var year, month, Datum;
    	var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "MMyyyy" });
    	Datum = oDateFormat.format(new Date()); 
    	year  = this.byId("idYear");
    	month = this.byId("idMonth");
    	if(this.byId("idMonth").getSelectedKey() === "" || this.byId("idYear").getSelectedKey() === ""){
    		return;
    	}
    	if(parseInt(year.getSelectedKey()) <= parseInt(Datum.substr(2,6)) && parseInt(month.getSelectedKey()) < parseInt(Datum.substr(0,2)) ){
    		sap.m.MessageBox.alert("Son kullanma tarihi geçmiş olamaz. Kontrol ediniz");
    		year.setSelectedKey("");
    		month.setSelectedKey("");
    		return;
    	} 
    	
    	
    },
    
    _bankTypeData: function(value){ 
    	
    	if(this.byId("vPosInstallmentSelect").getSelectedItem().mProperties.text == "Tek Çekim"){
    		
    		var taksit = 0 ;
    	}else{
    		var taksit = this.byId("vPosInstallmentSelect").getSelectedItem().mProperties.text[0] ;		
    	}
    	
    	return { 
    		Name                     : this.oControls.sVposCardName.getValue(), //BackEnd
    		Password                 : "",       //BackEnd
    		ClientId                 : "",       
    		Type                     : "",       //BackEnd
    		IPAddress                : "", 
    		Email                    : "",       //
    		OrderId                  : "",
    		GroupId                  : "",
    		TransId                  : "",
    		Total                    : parseFloat(this.oControls.vPosPayInput.getValue().replace(/[","]/g, '')),
    		Currency                 : this.oResourceBundle.getText("CURRENCY"),
    		Number                   : this.oControls.vPosCardNumber.getValue().substr(0,15).replace(/-/g, '') + window.number0 + window.number1 + window.number2 + window.number3,
    		Expires                  : (this.oControls.vPosMonth.getSelectedKey() 
    				+ "/" +this.oControls.vPosYear.getSelectedKey()).length == 6? "0" + this.oControls.vPosMonth.getSelectedKey() 
    				+ "/" +this.oControls.vPosYear.getSelectedKey():this.oControls.vPosMonth.getSelectedKey() + "/" +this.oControls.vPosYear.getSelectedKey(),
    		Cvv2Val                  : this.oControls.vPosCvc.getValue(),
    		Instalment               : taksit,
    		PayerSecurityLevel       : "",
    		PayerTxnId               : "",
    		PayerAuthenticationCode  : "",
    		Bukrs                    : this.UserInfo.Bukrs, 
    		Kunnr                    : this.UserInfo.Kunnr, 
//    		IsBankDetail	         : this.oView.getModel("OpenItemModel").oData.OpenItemCollectionthis._asd()
    		Itemno				     : this._selectedItem("ItemNum"),  //3 
    		FaturaNo				 : this._selectedItem("DocNo"),    //10
    		FaturaRefNo			     : this._selectedItem("RefDocNo"), //16
    		Bukrss 				     : this._selectedItem("CompCode"), //4
    		Gjahr				     : this._selectedItem("FiscYear"),  //10
    		Vade				     : this._selectedItem("Zzvade"),
    		BankType				 : this.sInstallmentCount === undefined ? this.oControls.sVPosBankSelect.getSelectedKey() : this.sInstallmentCount
    	};
    }, 
    
    _asd: function(){
    	var orderItem = this.bindDataIsBank;
    	for(var i = 0; i < orderItem.length; i++){
    		delete orderItem[i].__metadata;
    		delete orderItem[i].__proto__;
    		orderItem[i].LcAmount =  parseFloat(orderItem[i].LcAmount.replace(/[",","."]/g, ''));
    		orderItem[i].AmtDoccur =  parseFloat(orderItem[i].AmtDoccur.replace(/[",","."]/g, ''));
    		}
    	return orderItem;
    },
    
    _selectedItem: function(value){
        var oTable = this.byId("idBillTable");
        var selectedIndex = oTable.getSelectedIndices();
        var itemNo = "";
        for (var i = 0; i < selectedIndex.length; i++) {
            var oContext = oTable.getContextByIndex(selectedIndex[i]);
           itemNo = itemNo + oContext.getProperty(value) + ",";
        }
        return itemNo.substr(0, itemNo.length - 1);
        
    }, 
    
    _entityTypeData: function(value){
    	switch (value.substr(0,4)) {
		case "0064": // İş Bankası
			return "/IsbankPostFunction";
		case "0067": // İş Bankası
			return "/YapiKrediPostFunction";
		case "0062": // Garanti
			return "/GarantiPostFunction";
		case "0046": // Garanti
			return "/AkbankPostFunction";
		case "0012": // 
			return "/HalkbankPostFunction"; 
		default:
			break;
		}
    },

    _getPaymentInfo: function() {
        return {
            TransactionId: cus.PKT.BIMIADE.util.Util.getUniqueId(),
            Customer: "",
            ZCompanyCode: "",
            Amount: "",
            CompCode: ""
        };
    },

    _payInvoice: function(oPayment) {
        var t = this;
        sap.ui.core.BusyIndicator.show(0);
        if (t._checkSelectBox()) {
            var _invoiceResult = {
                InvoiceAmount: t.oControls.vPosPayInput.getValue(),
                OkUrl: t.OkUrl,
                FailUrl: t.FailUrl
            };
            t._getBankTrasaction(_invoiceResult);
        } else {
            sap.ui.core.BusyIndicator.hide();
        }
    },

    _getBankTrasaction: function(_invoiceDetail) {
        var t = this,
            storeId = t.oControls.sVPosBankSelect.getSelectedKey();
        return new Promise(function(resolve, reject) {
            var postFormStr = "<form method='post' action='" + t.oResourceBundle.getText(storeId) + "'>\n";
            var postData = t._getPostData(_invoiceDetail, storeId);
            for (var key in postData) {
                if (postData.hasOwnProperty(key)) {
                    postFormStr += "<input type='hidden' name='" + key + "' value='" + postData[key] + "'></input>";
                }
            } 
            postFormStr += "</form>";
            var formElement = $(postFormStr);
            $('body').append(formElement);
            $(formElement).submit();
        });
    },

    _getPostData: function(_invoiceDetail, storeId) {
        var postData = {
            clientid: this.oResourceBundle.getText(storeId + "_CLIENT_ID"),
            oid: this.sOId === undefined ? cus.PKT.BIMIADE.util.Util.getUniqueId() : this.sOId,
            amount: _invoiceDetail.InvoiceAmount,
            storetype: this.oResourceBundle.getText("3D_PAY_SORT_TYPE"),
            rnd: this.sRedirectRnd === undefined ? cus.PKT.BIMIADE.util.Util.getUniqueId() : this.sRnd,
            firmaadi: this.oResourceBundle.getText("FIRM_NAME"),
            islemtipi: this.oResourceBundle.getText("PROCESS_TYPE"),
            taksit: this.sInstallmentCount === undefined ? this.oControls.sVPosInstallmentSelect.getSelectedKey() : this.sInstallmentCount,
            lang: this.oResourceBundle.getText("LANGUAGE"),
            currency: this.oResourceBundle.getText("CURRENCY"),
            refreshtime: this.oResourceBundle.getText("REFRESH_TIME"),
            okUrl: _invoiceDetail.OkUrl,
            failUrl: _invoiceDetail.FailUrl,
            redirect_domain: window.location.origin + window.location.pathname,
            redirect_url: "#/InvoiceDetailStatus",
            redirect_partnerId: this.sPartnerId,
            redirect_invoiceId: this.sInvoiceId,
            redirect_storeId: storeId
        };
        postData.redirect_rnd = postData.rnd;
        postData.hash = cus.PKT.BIMIADE.util.Util.gethash(postData, storeId);
        return postData;
    }, 
    
	clearAllSortings : function(oEvent) {
		var oTable = this.getView().byId("idBillTable");
		oTable.getBinding("rows").sort(null);
		this._resetSortingState();
	},
	
	sortCategoriesAndName : function(oEvent) {
		var oView = this.getView();
		var oTable = oView.byId("idBillTable");  
		var oCategoriesColumn = oView.byId("DocNo");
		oTable.sort(oCategoriesColumn, this._bSortColumnDescending ? sap.ui.table.SortOrder.Descending : sap.ui.table.SortOrder.Ascending,true);
		this._bSortColumnDescending = !this._bSortColumnDescending;
 
		
	},

});
