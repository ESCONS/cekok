sap.ui.controller("cus.PKT.BIMIADE.view.App", {
    onInit: function() {
    	 
    }
,
onRoutePatternMatched: function(oEvent) {
	
	
	
}
});