jQuery.sap.declare("cus.PKT.BIMIADE.util.Util");
jQuery.sap.require("sap.ca.ui.quickoverview.Quickoverview");


String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};


cus.PKT.BIMIADE.util.Util = {
    MapLoaded: false,
    onNavBack: function(backPageCount, isLaunchpad) {
        var oHistory = sap.ui.core.routing.History.getInstance();
        var sPreviousHash = oHistory.getPreviousHash();
        if (sap.ushell) {
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
            if (isLaunchpad === undefined) {
                history.go(backPageCount);
            } else {
                //history.go(-1);
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: "#"
                    }
                });
            }
        } else {
            history.go(backPageCount);
        }
    },

    isEmpty: function(value) {
        return (typeof value == "string" && !value.trim() || typeof value == "undefined" || value === null);
    },

    _setResourceBundle: function(bundle) {
        this.oResourceBundle = bundle;
    },

    _getResourceBundle: function() {
        return this.oResourceBundle;
    },

    _generateTemplateUsingMetadata: function(_method, oDataModel) {
        var e = oDataModel.oMetadata._getEntityTypeByPath(_method);
        var t = {};
        for (var i in e.property) {
            if (e.property.hasOwnProperty(i)) {
                switch (e.property[i].type) {
                    case "Edm.Boolean":
                        {
                            t[e.property[i].name] = false;
                            break;
                        }
                    case "Edm.DateTime":
                        {
                            t[e.property[i].name] = null;
                            break;
                        }
                    case "Edm.Time":
                        {
                            t[e.property[i].name] = "PT00H00M00S";
                            break;
                        }
                    case "Edm.Int16":
                        {
                            t[e.property[i].name] = 0;
                            break;
                        }
                    case "Edm.Decimal":
                        {
                            t[e.property[i].name] = "0";
                            break;
                        }
                    default:
                        t[e.property[i].name] = "";
                        break;
                }
            }
        }
        return t;
    },

    _getI18nText: function(value) {
        return this._getResourceBundle().getText(value);
    },

    _fillNewObject: function(sourceObject, targetObject) {
        var t = this;
        var changesExist = false;
        for (var key in targetObject) {
            if (targetObject.hasOwnProperty(key)) {
                var index = t.findInObject(sourceObject,
                    function(value) {
                        if (value === undefined) {
                            return undefined;
                        } else {
                            if (sourceObject[key] === undefined) return targetObject[key];
                            else return targetObject[key] = sourceObject[key];
                            changesExist = true;
                        }
                    });
            }
        }
        return changesExist;
    },

    findInObject: function(_object, _callBack) {
        for (var _filed in _object) {
            if (_object.hasOwnProperty(_filed)) {
                if (_callBack(_object[_filed])) {
                    return _filed;
                }
            }
        }
        return undefined;
    },

    findInArray: function(_array, _callBack) {
        for (var i = 0, len = _array.length; i < len; ++i) {
            if (_callBack(_array[i])) {
                return i;
            }
        }
        return -1;
    },

    checkResponseHeader: function(header) {
        var returnData = false;
        var result = header["sap-message"];
        if (result) {
            var json = JSON.stringify(eval("(" + result + ")"));
            var obj = JSON.parse(json);
            if (obj.severity === "error") {
                var message = obj.message;
                sap.m.MessageBox.show(message,
                    sap.m.MessageBox.Icon.ERROR,
                    cus.PKT.BIMIADE.util.Util._getResourceBundle().getText("ERROR"), [sap.m.MessageBox.Action.OK]
                );
            } else if (obj.severity === "info") {
                var message = obj.message;
                sap.m.MessageBox.show(message,
                    sap.m.MessageBox.Icon.INFO,
                    cus.PKT.BIMIADE.util.Util._getResourceBundle().getText("SUCCESS"), [sap.m.MessageBox.Action.OK]
                );
                // returnData = true;
            }

            return returnData;
        }
        return false;
    },

    sendBatchChangeOperations: function(m, b, c, a) {
        m.clearBatch();
        m.addBatchChangeOperations(b);
        var t = this;
        m.submitBatch(jQuery.proxy(function(d) {
            var e = {};
            var B = d.__batchResponses;
            var r = [];
            for (var i = 0; i < B.length; i++) {
                if (B[i].response) {
                    e = jQuery.parseJSON(B[i].response.body).error;
                    e.statusCode = B[i].response.statusCode;
                    e.statusText = B[i].response.statusText;
                    cus.PKT.BIMIADE.util.Util.checkResponseHeader(B[i].response);
                }
                if (B[i].__changeResponses && B[i].__changeResponses.length > 0 && B[i].__changeResponses[0].statusCode === "201") {
                    r.push(B[i].__changeResponses[0].data);
                    cus.PKT.BIMIADE.util.Util.checkResponseHeader(B[i].__changeResponses[0].headers);
                }
            }
            if (!e.message) {
                if (c)
                    c.call(t, r);
            } else {
                if (a)
                    a.call(t, e);
                else
                    sap.m.MessageBox.alert(e.message.value);
            }
        }, this), function(error) {
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageBox.alert("SYSTEM_ERROR");
        }, true);
    },

    //Login işlemleri BEGIN

    b64EncodeUnicode: function(str) {
        return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function(match, p1) {
            return String.fromCharCode('0x' + p1);
        }));
    },

    b64DecodeUnicode: function(str) {
        return decodeURIComponent(atob(str).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
    },


    getCookie: function(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) === ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) === 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    },

    parseCookie: function(cname) {
        var cookie = this.getCookie(cname);
        if (cookie !== "") {
            var userInfo = this.b64DecodeUnicode(cookie).split("|");
            var user = {
                Uname: userInfo[0],
                Guid: userInfo[1],
                UserType: userInfo[2],
                Kunnr: userInfo[3],
                Bukrs: userInfo[4]
            };
            return user;
        }
        return "";
    },

    //Login işlemleri END

    //POS İşlemleri START

    getUniqueId: function() {
        var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyyMMddHHmmssSS" });
        return oDateFormat.format(new Date()) + Math.floor((Math.random() * 1000) + 1);
    },

    gethash: function(postData, storeId) {
        return b64_sha1(
            postData.clientid +
            postData.oid +
            postData.amount +
            postData.okUrl +
            postData.failUrl +
            postData.islemtipi +
            postData.taksit +
            postData.rnd +
            b64str(this._getResourceBundle().getText(storeId + "_STORE_KEY"))
            );
    },
    gethash3: function(postdata) {
        return b64_sha1(
        		postdata.clientid+
    	    	postdata.oid+
    	    	postdata.amount+
    	    	postdata.okUrl+
    	    	postdata.failUrl+
    	    	postdata.islemtipi+
    	    	postdata.taksit+
    	    	postdata.rnd+
    	    	postdata.isyerianahtari
            );
    },
    gethash2: function(postData ) {
        return b64_sha1(
            postData.clientid +
            postData.oid +
            postData.rnd 
            );
    },
    gethash4: function(postData ) {
        return b64_sha1(     postData
            );
    },

    fixHash: function(_hash) {
        return _hash.split(this._getResourceBundle().getText("HASH_VALUE")).join(this._getResourceBundle().getText("HASH_KEY"));
    },

    getDefaultSelectValue: function(keyText, valText) {
        return { key: this._getResourceBundle().getText(keyText), value: this._getResourceBundle().getText(valText) };
    },

    getMonths: function() {
        var months = [{ "Id": "01", "Name": "Ocak" },
		              { "Id": "02", "Name": "Şubat" },
		              { "Id": "03", "Name": "Mart" },
		              { "Id": "04", "Name": "Nisan" },
		              { "Id": "05", "Name": "Mayıs" },
		              { "Id": "06", "Name": "Haziran" },
		              { "Id": "07", "Name": "Temmuz" },
		              { "Id": "08", "Name": "Ağustos" },
		              { "Id": "09", "Name": "Eylül" },
		              { "Id": "10", "Name": "Ekim" },
		              { "Id": "11", "Name": "Kasım" },
		              { "Id": "12", "Name": "Aralık" }
        ];

        var defaultValue = cus.ecc.vpos.utils.Util.getDefaultSelectValue("DEFAULT_VALUE", "MONTH");
        months.unshift({
            Id: defaultValue.key,
            Name: defaultValue.value
        });
        return months;
    },

    getYears: function() {
        var years = [],
            thisYear = new Date().getFullYear();
        for (var i = 0; i < 11; i++) {
            years.push({
                Id: (thisYear + i).toString().substr(2, 2),
                Name: thisYear + i
            });
        }

        var defaultValue = cus.ecc.vpos.utils.Util.getDefaultSelectValue("DEFAULT_VALUE", "YEAR");
        years.unshift({
            Id: defaultValue.key,
            Name: defaultValue.value
        });
        return years;
    },

    //POS İşlemleri END 
		
}; 