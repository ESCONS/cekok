jQuery.sap.declare("cus.PKT.BIMIADE.util.formatter");

cus.PKT.BIMIADE.util.formatter = {
    dateFormatter: function(oDate, withText) {
        var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd.MM.yyyy" });
        return withText ?
            cus.PKT.BIMIADE.util.Util.oResourceBundle.getText("LAST_PAYMENT_DATE", oDateFormat.format(new Date(oDate))) :
            oDateFormat.format(new Date(oDate));
    },

    invoiceIdFormatter: function(invoiceId) {
        return cus.PKT.BIMIADE.util.Util.oResourceBundle.getText("INVOICE_ID", invoiceId);
    },

    amountFormatter: function(amount, currency) {
        amount = parseFloat(amount);
        return amount.toFixed(2).replace(/./g, function(c, i, a) {
            return i > 0 && c !== "." && (a.length - i) % 3 === 0 ? "," + c : c;
        }) + " " + currency;
    },

    amountFormatterWithoutCurrency: function(amount) {
        amount = parseFloat(amount);
        return amount.toFixed(2).replace(/./g, function(c, i, a) {
            return i > 0 && c !== "." && (a.length - i) % 3 === 0 ? "," + c : c;
        });
    },
    
    amountFormatterConna: function(amount){
        if (!amount) {
            return "";
        }  
        return amount.replace(",", "");

    },
    
    oDataTodateFormat: function(value){
    	if (!value) {
            return value;
        }
    	return value.substring(6, 8) + "." + value.substring(4, 6) + "." + value.substring(0, 4);
    },
    text: function(value){
    	if(value == null || value == ""){
    		return "Lütfen ödeme tipini seçiniz";
    	}
    	if(parseFloat(value) == 0){
    		return "Tek çekim";
    	}else if(parseFloat(value).toString() !== "NaN"){ 
        	return value + " Taksit" ;
    	}else {
    		return value;
    	}
    	
    },
    
};