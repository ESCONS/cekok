sap.ui.define(["urungiris/controller/BaseController"], function(BaseController) {
	"use strict";

	return BaseController.extend("urungiris.controller.App", {

		onInit: function() {

		}
	});

});